
export function showTargets(goalCode, targets) {
    // create a Modal background in html.

  const targetCardBG = document.querySelectorAll("section.goals");
  console.log(targetCardBG);

  // setting up the target card in html.

  const targetsWrapper = document.querySelector(".targets");
  targetsWrapper.classList.add("active");
  targetsWrapper.innerHTML = ""; 

  const targetCard = document.createElement("article");
  targetCard.classList.add("target-card");

  const targetContent = document.createElement("aside");
  targetContent.classList.add("target-content");

  const goalCodeElem = document.createElement("h2");
  const okButton = document.createElement("button");

  okButton.innerHTML = `OK`;
  goalCodeElem.innerHTML = `Goal ${goalCode}:`;

  targetCard.append(goalCodeElem);

    // loop over all goal targets, creat a <p> element for each target and append in targets card,


  for (let target of targets) {
    const targetElem = document.createElement("p");
    targetElem.innerHTML = `${target.code} . ${target.title}`;
    targetContent.append(targetElem);
    targetCard.append(targetContent);
  }

  targetCard.append(okButton);
  targetsWrapper.append(targetCard);

  // ok button to close the Modal.
  okButton.addEventListener("click", function () {
    targetsWrapper.classList.remove("active");
  });
  
  document.addEventListener("keyup", function (event) {
      if ( event.key === 'Escape' ){
    targetsWrapper.classList.remove("active");
     }
  });

}