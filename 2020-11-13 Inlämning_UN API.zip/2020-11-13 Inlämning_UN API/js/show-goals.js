
import { showTargets } from "./show-targets.js";

 export function showGoals (goals){
    // get the goals wrapper from html and make sure it is empty.
        const goalsWrapper = document.querySelector('.goals'); 
        goalsWrapper.innerHTML= '';
    
    // loop over all goals, creat a card for each then create h2, p, button elements,
        for ( let goal of goals) {
            const goalCard = document.createElement('article');
            goalCard.classList.add('goal-card');
    
            const goalElem = document.createElement('h2');
            const titleElem = document.createElement('p');
            const targetButton = document.createElement('button');
    
    // fill the elements with data from API goal objects
            targetButton.innerHTML = `more on goal ${goal.code}`;
            goalElem.innerHTML = `Goal ${goal.code} :`;
            titleElem.innerHTML = `${goal.title}` ; 
    
    // and append them into the card.
    
            goalCard.append(goalElem);
            goalCard.append(titleElem);
            goalCard.append(targetButton);
    
    // then append into the goals wrapper
            goalsWrapper.append(goalCard);
    
    
    // to show more info about a goal, onClick access its targets and display them.
            targetButton.addEventListener('click', function(){
                console.log('you clicked on: ' + goal.code + ' - '+ goal.title );
              showTargets ( goal.code, goal.targets)
            });
        }
    
    }