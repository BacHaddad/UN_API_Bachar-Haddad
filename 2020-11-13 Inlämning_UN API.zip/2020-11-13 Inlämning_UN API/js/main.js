
import { showGoals } from './show-goals.js';


// when the page is loaded. fetch the goals.

window.addEventListener('DOMContentLoaded', async function getGoals() {

    const goalsList_URL = "https://unstats.un.org/SDGAPI/v1/sdg/Goal/List?includechildren=true";
    
        try {
            const response =  await fetch (goalsList_URL);
            const data = await response.json();
            console.log(data);
            showGoals(data);

        } catch (error) {
            console.log('Error: ' + error);
        }
    
});
